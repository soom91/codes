const memoryCard = document.querySelectorAll('.memorycard'); // En const-variabel som styr alla memorykort.
let flippedCard=false; /* Bool om kortet är vänt på satt till false by defalut*/
let lockGameBoard=false; // Bool som låser spelbrädan satt till false by default.
let cardOne, cardTwo; /* skapar variablerna för Kort 1 och kort 2*/

function turnCard(){ /* En funktion som vänder på memorykorten*/
    if(lockGameBoard) return; // lockGameBoard sätts till true och hindrar något mer kort att snurra före korten är gömda eller att en matchning uppstått.
    if(this===cardOne) return; // Hindrar spelaren att klicka på samma kort två gånger.
    this.classList.add('turn'); // En egenskap som gör det möjligt att utforma css-klassen för elementet
    if(!flippedCard){ // Om kortet inte är vänt
        flippedCard=true; // Sätt boolen flippedCard till sann.
        cardOne=this; // cardOne=this  representerar således det kort som användaren klickar på
        return;
    }
    else{
        cardTwo=this; // CardTwo=this  representerar  således det kort som användaren klickar på
        flippedCard=false; // Sätt boolen flippedCard till false eftersom den ej ska vända tillbaka innan kontroll efter matchande kort utförts
        lookForMatch(); // Här anropas metoden loockForMatch som undersöker ifall korten matchar varandra.
    }
}
function lookForMatch(){ // Denna funktion kontrollerar om de båda korten som vänts upp matchar varandra eller ej.
    if(cardOne.dataset.framework===cardTwo.dataset.framework){ // Om kort ett och kort 2:s dataset matchar 
        disableCards(); // så ska korten klick funktionen och snurr-effekten på korten  avaktiveras.
        return;
    } 
    else{
        TurnbackCard(); //  Om det inte är en matchning  så vänds båda korten tillbaka.
    }
   
}
function disableCards(){ // Funktion som tar bort klickfunktionen och snurr-effekt på korten och återställer spelet.
    cardOne.removeEventListener('click',turnCard); // Tar bort klickfunktionen och snurr-funktionen på kort 1.
    cardTwo.removeEventListener('click',turnCard); // Tar bort klickfunktionen och snurr-funktionen på kort 2.
    clearBoard(); // Metodanrop som anropar metoden clearBoard som återställer spelet.
 
}
function TurnbackCard(){ // Funktion som vänder tillbaka korten i fall matchning ej uppstått med hjälp av en timeout-funktion på 1500 ms.
    lockGameBoard=true;
    setTimeout(()=>{ // https://developer.mozilla.org/en-US/docs/Web/API/setTimeout
    cardOne.classList.remove('turn'); // Tar bort klassen turn.
    cardTwo.classList.remove('turn');
   lockGameBoard=false},1500);
}
function clearBoard(){ // Funktion som återställer spelet.
 [flippedCard,lockGameBoard]=[false,false]; // Återställer booleans flippedCard,lockGameBoard till defaultvärde
 [cardOne,cardTwo]=[null,null]; // // Återställer booleans cardOne,cardTwo till null vilket betyder att de inte längre har ett värde. // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Destructuring_assignment
}
(function randomiseCard(){ // Här får varje kort ett eget slumpmässigt värde som tillskrivs kortets order- property, vilket placerar korten olika på spelplanen varje gång.
    memoryCard.forEach(card => { //For-each-Loopen går igenom alla kort som ligger i const memorycard och genererar ett slumpvärde mellan 0-11
    let randomValue=Math.floor(Math.random()*12);
    card.style.order=randomValue; // Här tilldelas order-propertyn ett slumpmässigt värde mellan 0-11 vilket gör att kortens position ändras varje gång sidan laddas.
    });
    
})();
memoryCard.forEach(card=>card.addEventListener('click',turnCard)); // Här tilldelas varje memorykort en klickfunktion som gör det möjligt för korten att vända sig.

